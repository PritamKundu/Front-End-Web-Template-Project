<?php
echo pranto
?>